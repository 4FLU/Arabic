﻿import React from "react";
import { motion } from "framer-motion";
import { MapPin, Calendar, Navigation2, Car, Compass } from "lucide-react";
import { weddingConfig } from "../config/weddingConfig";
import { GirihPattern, ElegantDivider } from "../assets/patterns";

export const Venue: React.FC = () => {
  const { venue, event } = weddingConfig;

  return (
    <section
      id="venue"
      className="relative py-24 px-4 sm:px-6 lg:px-8 w-full max-w-6xl mx-auto overflow-hidden"
    >
      <GirihPattern opacity={0.025} />

      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8 }}
        className="text-center space-y-3 mb-16"
      >
        <div className="inline-flex items-center gap-1.5 rounded-full border border-[#C5A059]/40 bg-cream/70 px-3.5 py-1 text-xs font-serif font-semibold tracking-widest text-[#1D4533] uppercase">
          <Compass className="h-3 w-3 text-[#C5A059]" />
          The Celebration
        </div>
        <h2 className="font-serif text-3xl sm:text-5xl font-bold tracking-tight text-[#1D4533]">
          Wedding Venue
        </h2>
        <p className="font-serif italic text-base text-[#5E3122]/80 max-w-lg mx-auto">
          An opulent sanctuary of grand Moorish courtyards, glistening fountains, and timeless beauty.
        </p>
        <ElegantDivider />
      </motion.div>

      {/* Luxury Venue Showcase Card */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.9 }}
        className="grid grid-cols-1 lg:grid-cols-12 rounded-3xl border border-[#C5A059]/40 bg-gradient-to-br from-cream/90 via-cream/70 to-[#F9D2BA]/25 shadow-[0_16px_48px_0_rgba(29,69,51,0.1)] backdrop-blur-xl overflow-hidden"
      >
        {/* Left Column: Atmospheric Architectural Venue Image */}
        <div className="lg:col-span-6 relative min-h-[320px] lg:min-h-full overflow-hidden">
          <img
            src="https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1200&q=80"
            alt={venue.name}
            loading="lazy"
            className="h-full w-full object-cover object-center filter saturate-[0.9] contrast-[1.05] transition-transform duration-700 hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#1D4533]/80 via-[#1D4533]/30 to-transparent" />

          {/* Overlay text on image */}
          <div className="absolute bottom-6 left-6 right-6 text-cream space-y-1">
            <span className="inline-block rounded-full bg-[#1D4533]/70 border border-[#C5A059]/40 px-3 py-1 text-[11px] font-serif uppercase tracking-widest text-[#F9D2BA] backdrop-blur-md">
              Palatial Destination
            </span>
            <h4 className="font-serif text-2xl sm:text-3xl font-bold text-[#F7EAE0]">
              {venue.name}
            </h4>
            <p className="text-xs sm:text-sm text-cream/80">
              {venue.tagline}
            </p>
          </div>
        </div>

        {/* Right Column: Venue Details & Google Maps Action */}
        <div className="lg:col-span-6 p-8 sm:p-10 flex flex-col justify-between space-y-8">
          <div className="space-y-6">
            <div className="space-y-2">
              <span className="text-xs uppercase font-bold tracking-widest text-[#C5A059] block">
                Grand Location
              </span>
              <h3 className="font-serif text-2xl sm:text-3xl font-bold text-[#1D4533]">
                {venue.name}
              </h3>
              <p className="font-serif italic text-sm text-[#5E3122]/90">
                {venue.tagline}
              </p>
            </div>

            {/* Address & Logistics Info */}
            <div className="space-y-4 pt-2">
              <div className="flex items-start gap-3.5">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-[#C5A059]/40 bg-cream/80 text-[#1D4533] shadow-sm">
                  <MapPin className="h-4 w-4 text-[#1D4533]" />
                </div>
                <div>
                  <p className="text-xs font-bold uppercase tracking-wider text-brown/70">
                    Address
                  </p>
                  <p className="text-sm font-semibold text-[#1D4533]">
                    {venue.address}
                  </p>
                  <p className="text-xs text-[#5E3122]/80">{venue.cityState}</p>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-[#C5A059]/40 bg-cream/80 text-[#1D4533] shadow-sm">
                  <Calendar className="h-4 w-4 text-[#1D4533]" />
                </div>
                <div>
                  <p className="text-xs font-bold uppercase tracking-wider text-brown/70">
                    Date & Arrival
                  </p>
                  <p className="text-sm font-semibold text-[#1D4533]">
                    {event.dayOfWeek}, {event.dateFormatted}
                  </p>
                  <p className="text-xs text-[#5E3122]/80">Doors open at 5:30 PM</p>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-[#C5A059]/40 bg-cream/80 text-[#1D4533] shadow-sm">
                  <Car className="h-4 w-4 text-[#1D4533]" />
                </div>
                <div>
                  <p className="text-xs font-bold uppercase tracking-wider text-brown/70">
                    Valet & Parking
                  </p>
                  <p className="text-xs text-[#5E3122]/85 leading-relaxed">
                    {venue.note}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Elegant Glassmorphism Button: VIEW ON GOOGLE MAPS */}
          <div className="pt-4 border-t border-[#C5A059]/30">
            <a
              href={venue.googleMapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="group flex w-full items-center justify-center gap-2.5 rounded-2xl border border-[#C5A059] bg-[#1D4533] py-3.5 px-6 text-xs sm:text-sm font-semibold tracking-widest text-[#F7EAE0] uppercase shadow-md backdrop-blur-md transition-all duration-300 hover:bg-[#143527] hover:shadow-xl hover:scale-[1.01]"
            >
              <Navigation2 className="h-4 w-4 text-[#F9D2BA] transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              <span>VIEW ON GOOGLE MAPS</span>
            </a>
          </div>
        </div>
      </motion.div>
    </section>
  );
};
