﻿import React, { useEffect, useRef } from "react";

interface Particle {
  x: number;
  y: number;
  radius: number;
  type: "leaf" | "petal" | "ornament" | "dust";
  vx: number;
  vy: number;
  rotation: number;
  vRot: number;
  opacity: number;
  color: string;
  depth: number;
}

export const FloatingDecorations: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };

    window.addEventListener("resize", handleResize);

    // Particle colors from the user palette
    const colors = [
      "#1D4533", // Emerald
      "#F9D2BA", // Soft Peach
      "#5E3122", // Deep Brown
      "#C5A059", // Subtle Gold
      "#EED9CB", // Soft Warm Cream
    ];

    const particleTypes: Particle["type"][] = [
      "leaf",
      "petal",
      "ornament",
      "dust",
    ];

    // Responsive particle count (reduced on mobile for high FPS)
    const count = window.innerWidth < 768 ? 22 : 45;
    const particles: Particle[] = [];

    for (let i = 0; i < count; i++) {
      const type = particleTypes[Math.floor(Math.random() * particleTypes.length)];
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        radius:
          type === "dust"
            ? Math.random() * 2 + 1
            : type === "ornament"
            ? Math.random() * 7 + 4
            : Math.random() * 6 + 4,
        type,
        vx: (Math.random() - 0.5) * 0.35,
        vy: Math.random() * 0.4 + 0.15, // Gentle downward/floating drift
        rotation: Math.random() * Math.PI * 2,
        vRot: (Math.random() - 0.5) * 0.015,
        opacity: Math.random() * 0.22 + 0.08, // Very low opacity, non-intrusive
        color: colors[Math.floor(Math.random() * colors.length)],
        depth: Math.random() * 0.8 + 0.2, // Layered depth
      });
    }

    let scrollY = window.scrollY;
    let targetScrollY = window.scrollY;

    const handleScroll = () => {
      targetScrollY = window.scrollY;
    };
    window.addEventListener("scroll", handleScroll, { passive: true });

    const drawLeaf = (
      c: CanvasRenderingContext2D,
      x: number,
      y: number,
      r: number,
      rot: number
    ) => {
      c.save();
      c.translate(x, y);
      c.rotate(rot);
      c.beginPath();
      // Graceful pointed olive / eucalyptus leaf
      c.moveTo(0, -r * 1.6);
      c.quadraticCurveTo(r * 0.8, 0, 0, r * 1.6);
      c.quadraticCurveTo(-r * 0.8, 0, 0, -r * 1.6);
      c.fill();
      // Center vein
      c.strokeStyle = "rgba(255, 255, 255, 0.2)";
      c.lineWidth = 0.5;
      c.stroke();
      c.restore();
    };

    const drawPetal = (
      c: CanvasRenderingContext2D,
      x: number,
      y: number,
      r: number,
      rot: number
    ) => {
      c.save();
      c.translate(x, y);
      c.rotate(rot);
      c.beginPath();
      // Soft rounded peach blossom petal
      c.moveTo(0, 0);
      c.bezierCurveTo(-r, -r * 0.7, -r * 0.8, -r * 1.6, 0, -r * 1.8);
      c.bezierCurveTo(r * 0.8, -r * 1.6, r, -r * 0.7, 0, 0);
      c.fill();
      c.restore();
    };

    const drawOrnament = (
      c: CanvasRenderingContext2D,
      x: number,
      y: number,
      r: number,
      rot: number
    ) => {
      c.save();
      c.translate(x, y);
      c.rotate(rot);
      // Subtle 8-pointed star / Islamic geometric motif
      c.beginPath();
      for (let i = 0; i < 8; i++) {
        const angle = (i * Math.PI) / 4;
        const dist = i % 2 === 0 ? r : r * 0.45;
        const px = Math.cos(angle) * dist;
        const py = Math.sin(angle) * dist;
        if (i === 0) c.moveTo(px, py);
        else c.lineTo(px, py);
      }
      c.closePath();
      c.stroke();
      c.restore();
    };

    const render = () => {
      // Smooth scroll interpolation for gentle parallax
      scrollY += (targetScrollY - scrollY) * 0.05;
      ctx.clearRect(0, 0, width, height);

      particles.forEach((p) => {
        // Natural floating motion
        p.x += p.vx + Math.sin(p.y * 0.005) * 0.25;
        p.y += p.vy;
        p.rotation += p.vRot;

        // Wrap around smoothly
        if (p.y > height + 40) {
          p.y = -30;
          p.x = Math.random() * width;
        }
        if (p.x < -30) p.x = width + 20;
        if (p.x > width + 30) p.x = -20;

        // Apply slight vertical scroll parallax
        const displayY = (p.y - scrollY * p.depth * 0.15) % height;
        const normalizedY = displayY < 0 ? displayY + height : displayY;

        ctx.fillStyle = p.color;
        ctx.strokeStyle = p.color;
        ctx.globalAlpha = p.opacity;

        if (p.type === "leaf") {
          drawLeaf(ctx, p.x, normalizedY, p.radius, p.rotation);
        } else if (p.type === "petal") {
          drawPetal(ctx, p.x, normalizedY, p.radius, p.rotation);
        } else if (p.type === "ornament") {
          ctx.lineWidth = 0.75;
          drawOrnament(ctx, p.x, normalizedY, p.radius, p.rotation);
        } else {
          // Dust sparkle
          ctx.beginPath();
          ctx.arc(p.x, normalizedY, p.radius, 0, Math.PI * 2);
          ctx.fill();
        }
      });

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener("resize", handleResize);
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="pointer-events-none fixed inset-0 z-10 h-full w-full"
      style={{ mixBlendMode: "multiply" }}
      aria-hidden="true"
    />
  );
};
