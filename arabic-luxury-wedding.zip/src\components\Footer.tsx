﻿import React from "react";
import { weddingConfig } from "../config/weddingConfig";

export const Footer: React.FC = () => {
  return (
    <footer className="relative py-12 px-4 text-center border-t border-[#C5A059]/20 overflow-hidden">
      <div className="max-w-md mx-auto space-y-3">
        {/* Monogram */}
        <div className="flex justify-center">
          <span className="font-serif text-sm font-semibold tracking-widest text-[#1D4533] uppercase">
            {weddingConfig.couple.monogram}
          </span>
        </div>

        <p className="font-serif text-xs tracking-wider text-[#5E3122]/60 uppercase">
          {weddingConfig.couple.bride.name} & {weddingConfig.couple.groom.name} • {weddingConfig.event.dateFormatted}
        </p>

        {/* Minimal Understated Branding */}
        <div className="pt-2">
          <p className="text-[11px] font-sans tracking-widest text-[#5E3122]/40">
            by PixelMint
          </p>
        </div>
      </div>
    </footer>
  );
};
