﻿import { useState } from "react";
import { Navigation } from "./components/Navigation";
import { Hero } from "./components/Hero";
import { WeddingDetails } from "./components/WeddingDetails";
import { Couple } from "./components/Couple";
import { ArabicQuote } from "./components/ArabicQuote";
import { Venue } from "./components/Venue";
import { RSVP } from "./components/RSVP";
import { Footer } from "./components/Footer";
import { FloatingDecorations } from "./components/FloatingDecorations";
import { AudioPlayer } from "./components/AudioPlayer";

export function App() {
  const [isMuted, setIsMuted] = useState(true);

  const toggleAudio = () => {
    setIsMuted((prev) => !prev);
  };

  return (
    <div className="relative min-h-screen bg-[#F7EAE0] text-[#5E3122] selection:bg-[#1D4533] selection:text-[#F7EAE0]">
      {/* Ambient Floating Elements (Leaves, Petals, Dust) */}
      <FloatingDecorations />

      {/* Floating Glass Navigation */}
      <Navigation isMuted={isMuted} toggleAudio={toggleAudio} />

      {/* Main Sections */}
      <main className="relative z-20 flex flex-col space-y-12 sm:space-y-20">
        <Hero />
        <WeddingDetails />
        <Couple />
        <ArabicQuote />
        <Venue />
        <RSVP />
      </main>

      {/* Subtle Floating Ambient Music Controller */}
      <AudioPlayer isMuted={isMuted} toggleAudio={toggleAudio} />

      {/* Elegant Minimal Footer */}
      <Footer />
    </div>
  );
}

export default App;
