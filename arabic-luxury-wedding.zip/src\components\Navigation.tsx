﻿import React, { useState, useEffect } from "react";
import { Menu, X, Volume2, VolumeX, Heart } from "lucide-react";
import { weddingConfig } from "../config/weddingConfig";

interface NavigationProps {
  isMuted: boolean;
  toggleAudio: () => void;
}

export const Navigation: React.FC<NavigationProps> = ({
  isMuted,
  toggleAudio,
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState("hero");

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 40);

      const sections = ["hero", "wedding", "couple", "quote", "venue", "rsvp"];
      const scrollPosition = window.scrollY + 200;

      for (const section of sections) {
        const el = document.getElementById(section);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { name: "Home", href: "#hero", id: "hero" },
    { name: "Wedding", href: "#wedding", id: "wedding" },
    { name: "Couple", href: "#couple", id: "couple" },
    { name: "Venue", href: "#venue", id: "venue" },
    { name: "RSVP", href: "#rsvp", id: "rsvp" },
  ];

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 flex justify-center px-4 pt-4 sm:pt-6 transition-all duration-500`}
      >
        <nav
          className={`relative flex w-full max-w-5xl items-center justify-between rounded-full border border-[#C5A059]/30 px-5 py-2.5 transition-all duration-500 ${
            isScrolled
              ? "bg-[#F7EAE0]/85 shadow-[0_8px_32px_0_rgba(29,69,51,0.12)] backdrop-blur-md"
              : "bg-[#F7EAE0]/60 backdrop-blur-sm shadow-[0_4px_20px_0_rgba(29,69,51,0.06)]"
          }`}
          aria-label="Main Navigation"
        >
          {/* Monogram Logo with Arabic Arch Accent */}
          <a
            href="#hero"
            className="group flex items-center gap-2.5 transition-opacity hover:opacity-90 focus:outline-none"
          >
            <div className="relative flex h-9 w-9 items-center justify-center rounded-full border border-[#C5A059] bg-[#1D4533] text-cream shadow-sm transition-transform duration-300 group-hover:scale-105">
              <span className="font-serif text-sm font-semibold tracking-wider text-[#F9D2BA]">
                {weddingConfig.couple.monogram}
              </span>
            </div>
            <div className="hidden sm:flex flex-col text-left">
              <span className="font-serif text-xs font-bold tracking-widest text-emerald uppercase">
                {weddingConfig.couple.bride.name} & {weddingConfig.couple.groom.name}
              </span>
              <span className="text-[10px] tracking-wider text-brown/70 uppercase">
                {weddingConfig.event.dateFormatted}
              </span>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <div className="hidden md:flex items-center gap-1.5 lg:gap-2">
            {navLinks.map((link) => {
              const isActive = activeSection === link.id;
              return (
                <a
                  key={link.name}
                  href={link.href}
                  className={`relative rounded-full px-4 py-1.5 text-xs font-medium tracking-wider uppercase transition-all duration-300 ${
                    isActive
                      ? "text-[#1D4533] font-semibold bg-[#F9D2BA]/40 shadow-sm"
                      : "text-[#5E3122]/80 hover:text-[#1D4533] hover:bg-cream/80"
                  }`}
                >
                  {link.name}
                  {isActive && (
                    <span className="absolute bottom-0 left-1/2 -translate-x-1/2 h-0.5 w-4 rounded-full bg-[#1D4533]" />
                  )}
                </a>
              );
            })}
          </div>

          {/* Right Action Icons: Audio toggle + Quick RSVP CTA */}
          <div className="flex items-center gap-2">
            {/* Ambient Sound Toggle */}
            <button
              onClick={toggleAudio}
              className="flex h-9 w-9 items-center justify-center rounded-full border border-[#C5A059]/40 bg-cream/70 text-[#1D4533] backdrop-blur-sm transition-all duration-300 hover:border-[#1D4533] hover:bg-[#1D4533] hover:text-cream"
              title={isMuted ? "Play Ambient Music" : "Mute Music"}
              aria-label={isMuted ? "Play Ambient Music" : "Mute Music"}
            >
              {isMuted ? (
                <VolumeX className="h-4 w-4" />
              ) : (
                <Volume2 className="h-4 w-4 animate-pulse" />
              )}
            </button>

            {/* Quick RSVP CTA (Desktop) */}
            <a
              href="#rsvp"
              className="hidden sm:inline-flex items-center gap-1.5 rounded-full bg-[#1D4533] px-4 py-2 text-xs font-semibold tracking-wider text-[#F7EAE0] shadow-sm transition-all duration-300 hover:bg-[#143527] hover:shadow-md hover:scale-[1.02] border border-[#C5A059]/40"
            >
              <Heart className="h-3 w-3 text-[#F9D2BA] fill-[#F9D2BA]" />
              <span>RSVP</span>
            </a>

            {/* Mobile Hamburger Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="flex h-9 w-9 md:hidden items-center justify-center rounded-full border border-[#C5A059]/40 bg-cream/70 text-[#1D4533] transition-colors hover:bg-cream"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? (
                <X className="h-4 w-4" />
              ) : (
                <Menu className="h-4 w-4" />
              )}
            </button>
          </div>
        </nav>
      </header>

      {/* Mobile Drawer Menu */}
      <div
        className={`fixed inset-0 z-40 md:hidden transition-all duration-500 ${
          mobileMenuOpen
            ? "opacity-100 pointer-events-auto"
            : "opacity-0 pointer-events-none"
        }`}
      >
        {/* Backdrop blur overlay */}
        <div
          onClick={() => setMobileMenuOpen(false)}
          className="absolute inset-0 bg-[#1D4533]/50 backdrop-blur-md transition-opacity"
        />

        {/* Drawer container */}
        <div
          className={`absolute top-20 left-4 right-4 rounded-3xl border border-[#C5A059]/40 bg-[#F7EAE0]/95 p-6 shadow-2xl backdrop-blur-xl transition-all duration-500 ${
            mobileMenuOpen
              ? "translate-y-0 scale-100 opacity-100"
              : "-translate-y-8 scale-95 opacity-0"
          }`}
        >
          <div className="flex flex-col items-center text-center space-y-4">
            <div className="h-10 w-10 flex items-center justify-center rounded-full bg-[#1D4533] text-[#F9D2BA] border border-[#C5A059] font-serif font-bold text-base shadow-sm">
              {weddingConfig.couple.monogram}
            </div>
            <p className="font-serif text-sm tracking-widest text-[#1D4533] uppercase">
              {weddingConfig.couple.bride.name} & {weddingConfig.couple.groom.name}
            </p>
            <div className="h-[1px] w-24 bg-[#C5A059]/40" />

            <div className="flex flex-col w-full space-y-2 pt-2">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className="rounded-xl py-2.5 text-sm font-medium tracking-wider text-[#5E3122] uppercase transition-colors hover:bg-[#F9D2BA]/40 hover:text-[#1D4533]"
                >
                  {link.name}
                </a>
              ))}
            </div>

            <div className="w-full pt-2">
              <a
                href="#rsvp"
                onClick={() => setMobileMenuOpen(false)}
                className="flex w-full items-center justify-center gap-2 rounded-full bg-[#1D4533] py-3 text-xs font-semibold tracking-wider text-cream border border-[#C5A059]/50 shadow-md uppercase"
              >
                <Heart className="h-3.5 w-3.5 text-[#F9D2BA] fill-[#F9D2BA]" />
                Confirm Attendance
              </a>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
