﻿import React from "react";

// Subtle Arabic Geometric Girih / Mashrabiya Lattice Background Pattern
export const GirihPattern: React.FC<{ className?: string; opacity?: number }> = ({
  className = "",
  opacity = 0.04,
}) => (
  <svg
    className={`pointer-events-none absolute inset-0 h-full w-full ${className}`}
    style={{ opacity }}
    xmlns="http://www.w3.org/2000/svg"
  >
    <defs>
      <pattern
        id="girih-tile"
        x="0"
        y="0"
        width="120"
        height="120"
        patternUnits="userSpaceOnUse"
      >
        {/* 8-pointed star and interlaced Moorish octagons */}
        <path
          d="M 60 15 L 75 45 L 105 60 L 75 75 L 60 105 L 45 75 L 15 60 L 45 45 Z"
          fill="none"
          stroke="#1D4533"
          strokeWidth="1"
        />
        <path
          d="M 60 0 L 70 30 L 100 30 L 75 50 L 85 80 L 60 65 L 35 80 L 45 50 L 20 30 L 50 30 Z"
          fill="none"
          stroke="#5E3122"
          strokeWidth="0.8"
        />
        <circle cx="60" cy="60" r="18" fill="none" stroke="#C5A059" strokeWidth="0.8" strokeDasharray="3 3" />
        <circle cx="0" cy="0" r="12" fill="none" stroke="#1D4533" strokeWidth="0.8" />
        <circle cx="120" cy="0" r="12" fill="none" stroke="#1D4533" strokeWidth="0.8" />
        <circle cx="0" cy="120" r="12" fill="none" stroke="#1D4533" strokeWidth="0.8" />
        <circle cx="120" cy="120" r="12" fill="none" stroke="#1D4533" strokeWidth="0.8" />
      </pattern>
    </defs>
    <rect width="100%" height="100%" fill="url(#girih-tile)" />
  </svg>
);

// Arabic Pointed Arch Frame (For Profile Pictures & Cards)
export const ArabicArchFrame: React.FC<{
  className?: string;
  children: React.ReactNode;
  borderColor?: string;
}> = ({ className = "", children, borderColor = "#C5A059" }) => (
  <div className={`relative ${className}`}>
    {/* SVG decorative border matching arch shape */}
    <div
      className="relative overflow-hidden shadow-2xl transition-transform duration-700 hover:scale-[1.01]"
      style={{
        clipPath:
          "polygon(50% 0%, 82% 12%, 100% 32%, 100% 100%, 0% 100%, 0% 32%, 18% 12%)",
        borderRadius: "16px",
      }}
    >
      {children}
    </div>
    {/* Decorative Arch Crest Line */}
    <svg
      className="pointer-events-none absolute -inset-[6px] h-[calc(100%+12px)] w-[calc(100%+12px)]"
      viewBox="0 0 300 400"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      preserveAspectRatio="none"
    >
      <path
        d="M 150 6 C 190 28 285 50 294 110 L 294 394 L 6 394 L 6 110 C 15 50 110 28 150 6 Z"
        stroke={borderColor}
        strokeWidth="1.5"
        strokeOpacity="0.6"
        strokeDasharray="4 2"
      />
      <circle cx="150" cy="6" r="3.5" fill={borderColor} />
    </svg>
  </div>
);

// Elegant Calligraphic Floral Divider
export const ElegantDivider: React.FC<{ className?: string }> = ({
  className = "",
}) => (
  <div className={`flex items-center justify-center gap-3 py-4 ${className}`}>
    <div className="h-[1px] w-12 sm:w-20 bg-gradient-to-r from-transparent to-[#C5A059]/60" />
    <svg
      width="32"
      height="18"
      viewBox="0 0 32 18"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="text-[#C5A059]"
    >
      {/* Arabic floral palmette */}
      <path
        d="M 16 2 C 18 6 22 9 26 9 C 22 9 19 12 18 16 C 17 12 14 9 10 9 C 14 9 15 6 16 2 Z"
        fill="currentColor"
        fillOpacity="0.8"
      />
      <circle cx="6" cy="9" r="1.5" fill="currentColor" fillOpacity="0.6" />
      <circle cx="26" cy="9" r="1.5" fill="currentColor" fillOpacity="0.6" />
    </svg>
    <div className="h-[1px] w-12 sm:w-20 bg-gradient-to-l from-transparent to-[#C5A059]/60" />
  </div>
);
