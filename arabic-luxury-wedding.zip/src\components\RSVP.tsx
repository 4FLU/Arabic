﻿import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  CheckCircle2,
  Heart,
  Users,
  Send,
  Sparkles,
  Utensils,
  RotateCcw,
} from "lucide-react";
import confetti from "canvas-confetti";
import { weddingConfig } from "../config/weddingConfig";
import { GirihPattern, ElegantDivider } from "../assets/patterns";

interface RSVPFormData {
  fullName: string;
  email: string;
  guestCount: number;
  attendance: "accept" | "decline";
  dietary: string;
  message: string;
}

export const RSVP: React.FC = () => {
  const [formData, setFormData] = useState<RSVPFormData>({
    fullName: "",
    email: "",
    guestCount: 1,
    attendance: "accept",
    dietary: weddingConfig.rsvp.dietaryOptions[0],
    message: "",
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [savedData, setSavedData] = useState<RSVPFormData | null>(null);

  // Load any previously saved RSVP from localStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem("amira_zayd_wedding_rsvp");
      if (saved) {
        const parsed = JSON.parse(saved);
        setSavedData(parsed);
        setIsSubmitted(true);
      }
    } catch {
      // Ignore localStorage errors
    }
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.fullName.trim()) return;

    setIsSubmitting(true);

    // Simulate network confirmation
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
      setSavedData(formData);

      try {
        localStorage.setItem(
          "amira_zayd_wedding_rsvp",
          JSON.stringify(formData)
        );
      } catch {
        // Ignore storage errors
      }

      // Elegant palette confetti shower
      confetti({
        particleCount: 75,
        spread: 70,
        origin: { y: 0.6 },
        colors: ["#1D4533", "#F9D2BA", "#C5A059", "#F7EAE0", "#5E3122"],
      });
    }, 800);
  };

  const handleReset = () => {
    setIsSubmitted(false);
  };

  return (
    <section
      id="rsvp"
      className="relative py-24 px-4 sm:px-6 lg:px-8 w-full max-w-4xl mx-auto overflow-hidden"
    >
      <GirihPattern opacity={0.03} />

      {/* Ambient background glow */}
      <div className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 h-[450px] w-[450px] rounded-full bg-[#F9D2BA]/30 blur-3xl -z-10" />

      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8 }}
        className="text-center space-y-3 mb-12"
      >
        <div className="inline-flex items-center gap-1.5 rounded-full border border-[#C5A059]/40 bg-cream/70 px-3.5 py-1 text-xs font-serif font-semibold tracking-widest text-[#1D4533] uppercase">
          <Sparkles className="h-3 w-3 text-[#C5A059]" />
          Your Gracious Presence
        </div>
        <h2 className="font-serif text-3xl sm:text-5xl font-bold tracking-tight text-[#1D4533]">
          Will You Join Us?
        </h2>
        <p className="font-serif italic text-base sm:text-lg text-[#5E3122]/85 max-w-lg mx-auto">
          We would be delighted to celebrate this special day with you.
        </p>
        <p className="text-xs uppercase tracking-widest font-semibold text-brown/70">
          Kindly respond by {weddingConfig.rsvp.deadline}
        </p>
        <ElegantDivider />
      </motion.div>

      {/* RSVP Form Container */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8 }}
        className="rounded-3xl border border-[#C5A059]/40 bg-gradient-to-b from-cream/90 via-cream/80 to-cream/70 p-6 sm:p-10 shadow-[0_16px_48px_0_rgba(29,69,51,0.1)] backdrop-blur-xl relative"
      >
        {/* Corner Moroccan Arch Details */}
        <div className="absolute top-3 left-3 h-4 w-4 border-t-2 border-l-2 border-[#C5A059]/50 rounded-tl-md" />
        <div className="absolute top-3 right-3 h-4 w-4 border-t-2 border-r-2 border-[#C5A059]/50 rounded-tr-md" />
        <div className="absolute bottom-3 left-3 h-4 w-4 border-b-2 border-l-2 border-[#C5A059]/50 rounded-bl-md" />
        <div className="absolute bottom-3 right-3 h-4 w-4 border-b-2 border-r-2 border-[#C5A059]/50 rounded-br-md" />

        <AnimatePresence mode="wait">
          {!isSubmitted ? (
            <motion.form
              key="rsvp-form"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onSubmit={handleSubmit}
              className="space-y-6"
            >
              {/* Attendance Toggle (Joyfully Accept / Regretfully Decline) */}
              <div className="space-y-2">
                <label className="block text-xs font-bold uppercase tracking-wider text-[#1D4533]">
                  Attendance Response *
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, attendance: "accept" })}
                    className={`flex items-center justify-center gap-2.5 rounded-2xl py-3.5 px-4 text-xs sm:text-sm font-semibold tracking-wider uppercase border transition-all duration-300 ${
                      formData.attendance === "accept"
                        ? "border-[#1D4533] bg-[#1D4533] text-cream shadow-md scale-[1.01]"
                        : "border-[#C5A059]/40 bg-cream/70 text-[#5E3122] hover:bg-cream"
                    }`}
                  >
                    <Heart
                      className={`h-4 w-4 ${
                        formData.attendance === "accept"
                          ? "fill-[#F9D2BA] text-[#F9D2BA]"
                          : "text-[#C5A059]"
                      }`}
                    />
                    <span>{weddingConfig.rsvp.options.accept}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, attendance: "decline" })}
                    className={`flex items-center justify-center gap-2.5 rounded-2xl py-3.5 px-4 text-xs sm:text-sm font-semibold tracking-wider uppercase border transition-all duration-300 ${
                      formData.attendance === "decline"
                        ? "border-[#5E3122] bg-[#5E3122] text-cream shadow-md scale-[1.01]"
                        : "border-[#C5A059]/40 bg-cream/70 text-[#5E3122] hover:bg-cream"
                    }`}
                  >
                    <span>{weddingConfig.rsvp.options.decline}</span>
                  </button>
                </div>
              </div>

              {/* Name & Email Fields */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div className="space-y-1.5">
                  <label
                    htmlFor="fullName"
                    className="block text-xs font-bold uppercase tracking-wider text-[#1D4533]"
                  >
                    Full Name *
                  </label>
                  <input
                    id="fullName"
                    type="text"
                    required
                    placeholder="e.g. Tariq Mansoor"
                    value={formData.fullName}
                    onChange={(e) =>
                      setFormData({ ...formData, fullName: e.target.value })
                    }
                    className="w-full rounded-2xl border border-[#C5A059]/40 bg-cream/80 px-4 py-3 text-sm text-[#5E3122] placeholder-[#5E3122]/40 backdrop-blur-sm transition-all focus:border-[#1D4533] focus:bg-cream focus:outline-none focus:ring-2 focus:ring-[#1D4533]/20"
                  />
                </div>

                <div className="space-y-1.5">
                  <label
                    htmlFor="email"
                    className="block text-xs font-bold uppercase tracking-wider text-[#1D4533]"
                  >
                    Email / Contact Number
                  </label>
                  <input
                    id="email"
                    type="text"
                    placeholder="e.g. tariq@example.com"
                    value={formData.email}
                    onChange={(e) =>
                      setFormData({ ...formData, email: e.target.value })
                    }
                    className="w-full rounded-2xl border border-[#C5A059]/40 bg-cream/80 px-4 py-3 text-sm text-[#5E3122] placeholder-[#5E3122]/40 backdrop-blur-sm transition-all focus:border-[#1D4533] focus:bg-cream focus:outline-none focus:ring-2 focus:ring-[#1D4533]/20"
                  />
                </div>
              </div>

              {/* Conditional Guests & Dietary if accepting */}
              {formData.attendance === "accept" && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 pt-1">
                  {/* Number of Guests */}
                  <div className="space-y-1.5">
                    <label
                      htmlFor="guestCount"
                      className="block text-xs font-bold uppercase tracking-wider text-[#1D4533]"
                    >
                      Number of Guests (Including You)
                    </label>
                    <div className="relative flex items-center">
                      <select
                        id="guestCount"
                        value={formData.guestCount}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            guestCount: Number(e.target.value),
                          })
                        }
                        className="w-full appearance-none rounded-2xl border border-[#C5A059]/40 bg-cream/80 px-4 py-3 text-sm text-[#5E3122] backdrop-blur-sm transition-all focus:border-[#1D4533] focus:bg-cream focus:outline-none focus:ring-2 focus:ring-[#1D4533]/20"
                      >
                        {Array.from(
                          { length: weddingConfig.rsvp.maxGuests },
                          (_, i) => i + 1
                        ).map((num) => (
                          <option key={num} value={num}>
                            {num} {num === 1 ? "Guest" : "Guests"}
                          </option>
                        ))}
                      </select>
                      <Users className="pointer-events-none absolute right-4 h-4 w-4 text-[#C5A059]" />
                    </div>
                  </div>

                  {/* Dietary Requirements */}
                  <div className="space-y-1.5">
                    <label
                      htmlFor="dietary"
                      className="block text-xs font-bold uppercase tracking-wider text-[#1D4533]"
                    >
                      Dietary Preferences
                    </label>
                    <div className="relative flex items-center">
                      <select
                        id="dietary"
                        value={formData.dietary}
                        onChange={(e) =>
                          setFormData({ ...formData, dietary: e.target.value })
                        }
                        className="w-full appearance-none rounded-2xl border border-[#C5A059]/40 bg-cream/80 px-4 py-3 text-sm text-[#5E3122] backdrop-blur-sm transition-all focus:border-[#1D4533] focus:bg-cream focus:outline-none focus:ring-2 focus:ring-[#1D4533]/20"
                      >
                        {weddingConfig.rsvp.dietaryOptions.map((opt) => (
                          <option key={opt} value={opt}>
                            {opt}
                          </option>
                        ))}
                      </select>
                      <Utensils className="pointer-events-none absolute right-4 h-4 w-4 text-[#C5A059]" />
                    </div>
                  </div>
                </div>
              )}

              {/* Optional message / Warm Wishes */}
              <div className="space-y-1.5">
                <label
                  htmlFor="message"
                  className="block text-xs font-bold uppercase tracking-wider text-[#1D4533]"
                >
                  Message / Warm Wishes for the Couple (Optional)
                </label>
                <textarea
                  id="message"
                  rows={3}
                  placeholder="Share a heartfelt blessing or message for Amira & Zayd..."
                  value={formData.message}
                  onChange={(e) =>
                    setFormData({ ...formData, message: e.target.value })
                  }
                  className="w-full rounded-2xl border border-[#C5A059]/40 bg-cream/80 px-4 py-3 text-sm text-[#5E3122] placeholder-[#5E3122]/40 backdrop-blur-sm transition-all focus:border-[#1D4533] focus:bg-cream focus:outline-none focus:ring-2 focus:ring-[#1D4533]/20 resize-none"
                />
              </div>

              {/* Submit Button */}
              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="group relative flex w-full items-center justify-center gap-2.5 rounded-2xl border border-[#C5A059] bg-[#1D4533] py-4 px-6 text-sm font-semibold tracking-widest text-[#F7EAE0] uppercase shadow-lg transition-all duration-300 hover:bg-[#143527] hover:shadow-xl hover:scale-[1.01] disabled:opacity-75"
                >
                  {isSubmitting ? (
                    <span className="flex items-center gap-2">
                      <span className="h-4 w-4 rounded-full border-2 border-cream border-t-transparent animate-spin" />
                      Recording RSVP...
                    </span>
                  ) : (
                    <>
                      <span>Submit RSVP</span>
                      <Send className="h-4 w-4 text-[#F9D2BA] transition-transform duration-300 group-hover:translate-x-1" />
                    </>
                  )}
                </button>
              </div>
            </motion.form>
          ) : (
            /* Success Card State */
            <motion.div
              key="rsvp-success"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6 }}
              className="py-10 px-4 text-center space-y-6"
            >
              <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full border-2 border-[#C5A059] bg-[#1D4533] text-[#F9D2BA] shadow-xl">
                <CheckCircle2 className="h-10 w-10 text-[#F9D2BA]" />
              </div>

              <div className="space-y-2">
                <h3 className="font-serif text-3xl sm:text-4xl font-bold text-[#1D4533]">
                  Thank You
                </h3>
                <p className="font-serif italic text-lg sm:text-xl text-[#5E3122]">
                  We can't wait to celebrate with you.
                </p>
              </div>

              {savedData && (
                <div className="max-w-md mx-auto rounded-2xl border border-[#C5A059]/30 bg-cream/90 p-5 text-left text-xs space-y-2.5 shadow-sm">
                  <div className="flex justify-between border-b border-[#C5A059]/20 pb-2">
                    <span className="text-brown/70 font-medium">Guest:</span>
                    <span className="font-semibold text-[#1D4533]">
                      {savedData.fullName}
                    </span>
                  </div>
                  <div className="flex justify-between border-b border-[#C5A059]/20 pb-2">
                    <span className="text-brown/70 font-medium">Response:</span>
                    <span className="font-semibold text-[#1D4533]">
                      {savedData.attendance === "accept"
                        ? "Joyfully Attending"
                        : "Regretfully Declining"}
                    </span>
                  </div>
                  {savedData.attendance === "accept" && (
                    <div className="flex justify-between border-b border-[#C5A059]/20 pb-2">
                      <span className="text-brown/70 font-medium">
                        Total Guests:
                      </span>
                      <span className="font-semibold text-[#1D4533]">
                        {savedData.guestCount}
                      </span>
                    </div>
                  )}
                  {savedData.message && (
                    <div className="pt-1">
                      <span className="text-brown/70 font-medium block">
                        Your Note:
                      </span>
                      <p className="italic text-[#5E3122]/90 mt-0.5">
                        "{savedData.message}"
                      </p>
                    </div>
                  )}
                </div>
              )}

              <div className="pt-2">
                <button
                  type="button"
                  onClick={handleReset}
                  className="inline-flex items-center gap-2 text-xs font-semibold tracking-wider text-brown/70 hover:text-[#1D4533] uppercase transition-colors"
                >
                  <RotateCcw className="h-3.5 w-3.5" />
                  <span>Update your RSVP response</span>
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </section>
  );
};
