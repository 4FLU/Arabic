﻿import React from "react";
import { motion } from "framer-motion";
import { Heart, Sparkles } from "lucide-react";
import { weddingConfig } from "../config/weddingConfig";
import { GirihPattern, ElegantDivider, ArabicArchFrame } from "../assets/patterns";

export const Couple: React.FC = () => {
  const { bride, groom, monogram } = weddingConfig.couple;

  return (
    <section
      id="couple"
      className="relative py-24 px-4 sm:px-6 lg:px-8 w-full max-w-6xl mx-auto overflow-hidden"
    >
      <GirihPattern opacity={0.03} />

      {/* Section Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8 }}
        className="text-center space-y-3 mb-16"
      >
        <div className="inline-flex items-center gap-1.5 rounded-full border border-[#C5A059]/40 bg-cream/70 px-3.5 py-1 text-xs font-serif font-semibold tracking-widest text-[#1D4533] uppercase">
          <Sparkles className="h-3 w-3 text-[#C5A059]" />
          The Blessed Couple
        </div>
        <h2 className="font-serif text-3xl sm:text-5xl font-bold tracking-tight text-[#1D4533]">
          Bride & Groom
        </h2>
        <p className="font-serif italic text-base text-[#5E3122]/80 max-w-lg mx-auto">
          Two souls destined by grace, bound by love, and embarking on a timeless journey together.
        </p>
        <ElegantDivider />
      </motion.div>

      {/* Couple Profiles Grid */}
      <div className="relative grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-8 items-center">
        {/* Bride Profile (Left Column) */}
        <motion.div
          initial={{ opacity: 0, x: -40 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
          className="lg:col-span-5 flex flex-col items-center text-center space-y-6"
        >
          {/* Portrait with Arabic Arch Frame */}
          <div className="relative w-64 sm:w-72">
            {/* Ambient gold/peach glow behind arch */}
            <div className="absolute -inset-2 rounded-3xl bg-gradient-to-t from-[#F9D2BA]/40 to-[#1D4533]/15 blur-xl -z-10" />

            <ArabicArchFrame borderColor="#C5A059">
              <div className="relative aspect-[3/4] w-full overflow-hidden bg-cream">
                <img
                  src={bride.image}
                  alt={bride.fullName}
                  loading="lazy"
                  className="h-full w-full object-cover object-center filter saturate-[0.85] contrast-[1.05] transition-transform duration-700 hover:scale-105"
                />
                {/* Subtle vignette gradient */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#1D4533]/40 via-transparent to-transparent pointer-events-none" />
              </div>
            </ArabicArchFrame>

            {/* Floating Role Pill Badge */}
            <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 rounded-full border border-[#C5A059] bg-[#F7EAE0] px-4 py-1 shadow-md">
              <span className="font-serif text-xs font-bold uppercase tracking-widest text-[#1D4533]">
                {bride.title}
              </span>
            </div>
          </div>

          {/* Bride Details */}
          <div className="space-y-2 pt-2 max-w-sm">
            <h3 className="font-serif text-3xl sm:text-4xl font-bold tracking-tight text-[#1D4533]">
              {bride.fullName}
            </h3>
            <p className="text-xs uppercase tracking-widest font-semibold text-[#5E3122]/70">
              Daughter of Tariq & Layla
            </p>
            <p className="text-sm text-[#5E3122]/85 leading-relaxed pt-2 font-normal">
              {bride.description}
            </p>
          </div>
        </motion.div>

        {/* Center Connection Medallion (Desktop) */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="lg:col-span-2 flex flex-col items-center justify-center my-4 lg:my-0"
        >
          <div className="relative flex h-16 w-16 items-center justify-center rounded-full border-2 border-[#C5A059] bg-[#F7EAE0] shadow-xl backdrop-blur-md">
            {/* Subtle rotating glow ring */}
            <div className="absolute -inset-1 rounded-full border border-[#1D4533]/20 animate-[spin_12s_linear_infinite]" />
            <span className="font-serif text-lg font-bold text-[#1D4533]">
              {monogram}
            </span>
          </div>
          <span className="hidden lg:block h-16 w-0.5 bg-gradient-to-b from-[#C5A059] to-transparent mt-3" />
        </motion.div>

        {/* Groom Profile (Right Column) */}
        <motion.div
          initial={{ opacity: 0, x: 40 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
          className="lg:col-span-5 flex flex-col items-center text-center space-y-6"
        >
          {/* Portrait with Arabic Arch Frame */}
          <div className="relative w-64 sm:w-72">
            {/* Ambient gold/peach glow behind arch */}
            <div className="absolute -inset-2 rounded-3xl bg-gradient-to-t from-[#1D4533]/20 to-[#F9D2BA]/30 blur-xl -z-10" />

            <ArabicArchFrame borderColor="#C5A059">
              <div className="relative aspect-[3/4] w-full overflow-hidden bg-cream">
                <img
                  src={groom.image}
                  alt={groom.fullName}
                  loading="lazy"
                  className="h-full w-full object-cover object-center filter saturate-[0.85] contrast-[1.05] transition-transform duration-700 hover:scale-105"
                />
                {/* Subtle vignette gradient */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#1D4533]/40 via-transparent to-transparent pointer-events-none" />
              </div>
            </ArabicArchFrame>

            {/* Floating Role Pill Badge */}
            <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 rounded-full border border-[#C5A059] bg-[#F7EAE0] px-4 py-1 shadow-md">
              <span className="font-serif text-xs font-bold uppercase tracking-widest text-[#1D4533]">
                {groom.title}
              </span>
            </div>
          </div>

          {/* Groom Details */}
          <div className="space-y-2 pt-2 max-w-sm">
            <h3 className="font-serif text-3xl sm:text-4xl font-bold tracking-tight text-[#1D4533]">
              {groom.fullName}
            </h3>
            <p className="text-xs uppercase tracking-widest font-semibold text-[#5E3122]/70">
              Son of Khalid & Fatima
            </p>
            <p className="text-sm text-[#5E3122]/85 leading-relaxed pt-2 font-normal">
              {groom.description}
            </p>
          </div>
        </motion.div>
      </div>

      {/* Decorative End Accent */}
      <div className="mt-16 flex justify-center">
        <div className="inline-flex items-center gap-3 rounded-full border border-[#C5A059]/30 bg-cream/70 px-6 py-2 shadow-sm">
          <Heart className="h-3.5 w-3.5 text-[#C5A059] fill-[#C5A059]" />
          <span className="font-serif text-xs tracking-widest text-[#5E3122] uppercase">
            United in Faith & Harmony
          </span>
          <Heart className="h-3.5 w-3.5 text-[#C5A059] fill-[#C5A059]" />
        </div>
      </div>
    </section>
  );
};
