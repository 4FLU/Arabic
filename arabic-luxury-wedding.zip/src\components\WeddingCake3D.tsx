﻿import React, { useRef, useState, useMemo, Suspense } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { Float, ContactShadows, OrbitControls } from "@react-three/drei";
import * as THREE from "three";

// Procedural Luxury Arabic-Inspired Wedding Cake
const ProceduralCake: React.FC = () => {
  const cakeGroup = useRef<THREE.Group>(null);
  const [hovered, setHovered] = useState(false);

  // Smooth rotation & subtle mouse response
  useFrame((state, delta) => {
    if (cakeGroup.current) {
      // Continuous slow majestic rotation
      cakeGroup.current.rotation.y += delta * 0.25;

      // Gentle mouse parallax tilt
      const targetRotationX = (state.mouse.y * 0.15) - 0.05;
      cakeGroup.current.rotation.x = THREE.MathUtils.lerp(
        cakeGroup.current.rotation.x,
        targetRotationX,
        0.05
      );
    }
  });

  // Materials matching luxury palette
  const materials = useMemo(() => {
    return {
      fondantIvory: new THREE.MeshStandardMaterial({
        color: new THREE.Color("#F7EAE0"),
        roughness: 0.28,
        metalness: 0.05,
      }),
      fondantPeach: new THREE.MeshStandardMaterial({
        color: new THREE.Color("#FCE4D6"),
        roughness: 0.3,
        metalness: 0.05,
      }),
      emeraldTrim: new THREE.MeshStandardMaterial({
        color: new THREE.Color("#1D4533"),
        roughness: 0.35,
        metalness: 0.2,
      }),
      goldFiligree: new THREE.MeshStandardMaterial({
        color: new THREE.Color("#C5A059"),
        roughness: 0.2,
        metalness: 0.85,
      }),
      pearlSugar: new THREE.MeshStandardMaterial({
        color: new THREE.Color("#FFF8F2"),
        roughness: 0.15,
        metalness: 0.1,
      }),
      sugarRose: new THREE.MeshStandardMaterial({
        color: new THREE.Color("#F9D2BA"),
        roughness: 0.45,
        metalness: 0.0,
      }),
      roseDeep: new THREE.MeshStandardMaterial({
        color: new THREE.Color("#E89B7B"),
        roughness: 0.45,
        metalness: 0.0,
      }),
      leafEmerald: new THREE.MeshStandardMaterial({
        color: new THREE.Color("#1D4533"),
        roughness: 0.4,
        metalness: 0.1,
      }),
      cakeStand: new THREE.MeshStandardMaterial({
        color: new THREE.Color("#F4E8DC"),
        roughness: 0.1,
        metalness: 0.4,
      }),
      goldStandRim: new THREE.MeshStandardMaterial({
        color: new THREE.Color("#D4AF37"),
        roughness: 0.15,
        metalness: 0.9,
      }),
    };
  }, []);

  // Procedural pearls generator
  const createPearlRing = (radius: number, y: number, count: number = 36) => {
    const pearls = [];
    for (let i = 0; i < count; i++) {
      const angle = (i / count) * Math.PI * 2;
      const px = Math.cos(angle) * radius;
      const pz = Math.sin(angle) * radius;
      pearls.push(
        <mesh
          key={`pearl-${radius}-${i}`}
          position={[px, y, pz]}
          material={materials.pearlSugar}
        >
          <sphereGeometry args={[0.042, 12, 12]} />
        </mesh>
      );
    }
    return pearls;
  };

  // Floral cluster generator
  const createFlower = (
    position: [number, number, number],
    rotation: [number, number, number],
    scale: number = 1
  ) => (
    <group position={position} rotation={rotation} scale={scale}>
      {/* Rose center */}
      <mesh material={materials.roseDeep}>
        <sphereGeometry args={[0.08, 12, 12]} />
      </mesh>
      {/* Surrounding Petals */}
      {[0, 1, 2, 3, 4].map((i) => {
        const angle = (i / 5) * Math.PI * 2;
        return (
          <mesh
            key={`petal-${i}`}
            position={[Math.cos(angle) * 0.09, 0, Math.sin(angle) * 0.09]}
            rotation={[0.3, angle, 0]}
            material={materials.sugarRose}
          >
            <sphereGeometry args={[0.08, 10, 10]} />
          </mesh>
        );
      })}
      {/* Emerald eucalyptus leaf */}
      <mesh
        position={[0.14, -0.02, 0]}
        rotation={[0.2, 0.4, -0.4]}
        material={materials.leafEmerald}
      >
        <coneGeometry args={[0.08, 0.22, 5]} />
      </mesh>
      <mesh
        position={[-0.12, -0.02, 0.08]}
        rotation={[-0.2, -0.5, 0.3]}
        material={materials.leafEmerald}
      >
        <coneGeometry args={[0.07, 0.2, 5]} />
      </mesh>
    </group>
  );

  return (
    <group
      ref={cakeGroup}
      onPointerOver={() => setHovered(true)}
      onPointerOut={() => setHovered(false)}
      scale={hovered ? 1.02 : 1.0}
      position={[0, -0.7, 0]}
    >
      {/* ================= PEDESTAL STAND ================= */}
      {/* Base foot */}
      <mesh position={[0, -0.45, 0]} material={materials.cakeStand}>
        <cylinderGeometry args={[1.15, 1.25, 0.08, 48]} />
      </mesh>
      <mesh position={[0, -0.45, 0]} material={materials.goldStandRim}>
        <torusGeometry args={[1.22, 0.025, 16, 48]} />
      </mesh>
      {/* Stem */}
      <mesh position={[0, -0.25, 0]} material={materials.cakeStand}>
        <cylinderGeometry args={[0.3, 0.45, 0.35, 32]} />
      </mesh>
      {/* Stand plate */}
      <mesh position={[0, -0.05, 0]} material={materials.cakeStand}>
        <cylinderGeometry args={[1.7, 1.6, 0.08, 48]} />
      </mesh>
      <mesh position={[0, -0.05, 0]} material={materials.goldStandRim}>
        <torusGeometry args={[1.68, 0.03, 16, 48]} />
      </mesh>

      {/* ================= TIER 1 (BOTTOM) ================= */}
      <mesh position={[0, 0.45, 0]} material={materials.fondantIvory}>
        <cylinderGeometry args={[1.4, 1.4, 0.9, 48]} />
      </mesh>
      {/* Emerald ribbon at base of Tier 1 */}
      <mesh position={[0, 0.08, 0]} material={materials.emeraldTrim}>
        <cylinderGeometry args={[1.41, 1.41, 0.14, 48]} />
      </mesh>
      <mesh position={[0, 0.15, 0]} material={materials.goldFiligree}>
        <torusGeometry args={[1.415, 0.015, 16, 48]} />
      </mesh>
      {/* Pearl Ring bottom & top of Tier 1 */}
      {createPearlRing(1.42, 0.03, 44)}
      {createPearlRing(1.41, 0.89, 44)}

      {/* ================= TIER 2 (MIDDLE) ================= */}
      <mesh position={[0, 1.25, 0]} material={materials.fondantPeach}>
        <cylinderGeometry args={[1.0, 1.0, 0.8, 48]} />
      </mesh>
      {/* Gold decorative filigree band around Tier 2 */}
      <mesh position={[0, 1.25, 0]} material={materials.goldFiligree}>
        <cylinderGeometry args={[1.01, 1.01, 0.08, 48]} />
      </mesh>
      {/* Emerald ribbon base of Tier 2 */}
      <mesh position={[0, 0.92, 0]} material={materials.emeraldTrim}>
        <cylinderGeometry args={[1.01, 1.01, 0.1, 48]} />
      </mesh>
      {/* Pearl Ring on Tier 2 */}
      {createPearlRing(1.02, 0.87, 36)}
      {createPearlRing(1.01, 1.64, 36)}

      {/* ================= TIER 3 (TOP) ================= */}
      <mesh position={[0, 1.95, 0]} material={materials.fondantIvory}>
        <cylinderGeometry args={[0.65, 0.65, 0.7, 48]} />
      </mesh>
      {/* Emerald & Gold rim */}
      <mesh position={[0, 1.63, 0]} material={materials.emeraldTrim}>
        <cylinderGeometry args={[0.66, 0.66, 0.08, 48]} />
      </mesh>
      {createPearlRing(0.67, 1.62, 28)}
      {createPearlRing(0.66, 2.29, 28)}

      {/* ================= CASCADING FLOWERS & LEAVES ================= */}
      {/* Top crown bouquet */}
      {createFlower([0.2, 2.38, 0.25], [0.3, 0.2, 0], 1.1)}
      {createFlower([-0.15, 2.36, -0.1], [-0.2, 0.5, 0.1], 0.95)}
      {createFlower([0, 2.4, -0.25], [0, 0, 0.3], 0.9)}

      {/* Mid-tier cascade */}
      {createFlower([0.85, 1.5, 0.5], [0.4, 0.8, 0.2], 1.0)}
      {createFlower([0.92, 1.1, 0.4], [0.2, 1.1, -0.1], 0.85)}

      {/* Bottom tier cascade */}
      {createFlower([1.25, 0.6, 0.65], [0.3, 0.9, 0.1], 1.15)}
      {createFlower([1.35, 0.2, 0.5], [0.1, 1.2, -0.2], 1.0)}

      {/* ================= CAKE TOPPER ================= */}
      {/* Elegant Arabic Arch Crest Topper */}
      <group position={[0, 2.52, 0]}>
        {/* Arch crest outline */}
        <mesh material={materials.goldFiligree}>
          <torusGeometry args={[0.22, 0.02, 16, 32, Math.PI]} />
        </mesh>
        {/* Center crescent & star pin */}
        <mesh position={[0, 0.12, 0]} material={materials.goldFiligree}>
          <sphereGeometry args={[0.035, 12, 12]} />
        </mesh>
        <mesh position={[0, -0.05, 0]} material={materials.goldFiligree}>
          <cylinderGeometry args={[0.015, 0.015, 0.22, 16]} />
        </mesh>
      </group>
    </group>
  );
};

export const WeddingCake3D: React.FC<{ className?: string }> = ({
  className = "",
}) => {
  return (
    <div className={`relative h-[420px] w-full max-w-[460px] select-none ${className}`}>
      {/* Soft golden & peach ambient glow behind cake */}
      <div
        className="pointer-events-none absolute inset-0 -z-10 rounded-full blur-3xl"
        style={{
          background:
            "radial-gradient(circle, rgba(249, 210, 186, 0.32) 0%, rgba(197, 160, 89, 0.18) 45%, rgba(29, 69, 51, 0) 75%)",
        }}
      />

      <Canvas
        camera={{ position: [0, 1.8, 5.0], fov: 42 }}
        dpr={[1, 2]}
        gl={{ antialias: true, alpha: true, powerPreference: "high-performance" }}
        className="touch-none"
      >
        <Suspense fallback={null}>
          {/* Subtle studio lighting */}
          <ambientLight intensity={0.8} />
          {/* Main Key Light: Warm golden wedding glow */}
          <directionalLight
            position={[4, 6, 4]}
            intensity={1.5}
            color="#FFF4E6"
            castShadow
          />
          {/* Fill Light: Soft Peach */}
          <pointLight position={[-4, 2, -2]} intensity={0.7} color="#F9D2BA" />
          {/* Rim Light: Deep Emerald luxury contrast accent */}
          <directionalLight
            position={[0, 3, -5]}
            intensity={0.9}
            color="#2A5F47"
          />

          <Float
            speed={1.5}
            rotationIntensity={0.2}
            floatIntensity={0.3}
            floatingRange={[-0.05, 0.05]}
          >
            <ProceduralCake />
          </Float>

          {/* Soft contact shadow beneath pedestal */}
          <ContactShadows
            position={[0, -1.2, 0]}
            opacity={0.35}
            scale={5}
            blur={2.5}
            far={4}
            color="#1D4533"
          />

          {/* Allows user interaction: orbit / spin with damping */}
          <OrbitControls
            enableZoom={false}
            enablePan={false}
            minPolarAngle={Math.PI / 3}
            maxPolarAngle={Math.PI / 2.05}
            autoRotate={false}
            rotateSpeed={0.7}
          />
        </Suspense>
      </Canvas>

      {/* Gentle interaction tooltip */}
      <div className="pointer-events-none absolute bottom-1 left-1/2 -translate-x-1/2 text-center">
        <span className="inline-flex items-center gap-1.5 rounded-full bg-cream/70 px-3 py-1 text-[11px] font-medium tracking-wider text-brown/70 backdrop-blur-md border border-[#C5A059]/30">
          <span className="h-1.5 w-1.5 rounded-full bg-[#1D4533] animate-pulse" />
          INTERACTIVE 3D • DRAG TO ROTATE
        </span>
      </div>
    </div>
  );
};
