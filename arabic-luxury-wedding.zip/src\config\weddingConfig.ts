﻿export interface WeddingConfig {
  couple: {
    bride: {
      name: string;
      fullName: string;
      title: string;
      description: string;
      image: string;
    };
    groom: {
      name: string;
      fullName: string;
      title: string;
      description: string;
      image: string;
    };
    monogram: string;
  };
  event: {
    title: string;
    subtitle: string;
    dateISO: string; // Used for countdown
    dateFormatted: string;
    dayOfWeek: string;
    time: string;
    ceremonyTime: string;
    receptionTime: string;
    dressCode: string;
  };
  arabicQuote: {
    arabic: string;
    english: string;
    surahOrSource: string;
  };
  timeline: Array<{
    time: string;
    title: string;
    description: string;
    icon: 'welcome' | 'ceremony' | 'dinner' | 'celebration';
  }>;
  venue: {
    name: string;
    tagline: string;
    address: string;
    cityState: string;
    googleMapsUrl: string;
    note: string;
  };
  rsvp: {
    deadline: string;
    maxGuests: number;
    options: {
      accept: string;
      decline: string;
    };
    dietaryOptions: string[];
  };
  audio: {
    title: string;
    artist: string;
    src: string;
  };
}

export const weddingConfig: WeddingConfig = {
  couple: {
    bride: {
      name: "Amira",
      fullName: "Amira Al-Mansoor",
      title: "The Bride",
      description: "A graceful soul whose warmth, kindness, and artistic heart brighten every room. Daughter of Tariq & Layla Al-Mansoor.",
      image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=800&q=80",
    },
    groom: {
      name: "Zayd",
      fullName: "Zayd Al-Hassan",
      title: "The Groom",
      description: "A thoughtful spirit of steadfast devotion, generosity, and boundless vision. Son of Khalid & Fatima Al-Hassan.",
      image: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=800&q=80",
    },
    monogram: "A & Z",
  },
  event: {
    title: "Welcome to Our Wedding",
    subtitle: "A Celebration of Love, Togetherness & Forever",
    dateISO: "2026-12-12T18:30:00",
    dateFormatted: "12 December 2026",
    dayOfWeek: "Saturday",
    time: "6:30 PM",
    ceremonyTime: "6:30 PM",
    receptionTime: "8:00 PM",
    dressCode: "Black Tie & Elegant Arabic Formal Attire",
  },
  arabicQuote: {
    arabic: "وَمِنْ آيَاتِهِ أَنْ خَلَقَ لَكُم مِّنْ أَنفُسِكُمْ أَزْوَاجًا لِّتَسْكُنُوا إِلَيْهَا وَجَعَلَ بَيْنَكُم مَّوَدَّةً وَرَحْمَةً",
    english: "And among His signs is that He created for you mates from among yourselves that you may dwell in tranquility with them, and He has put love and mercy between your hearts.",
    surahOrSource: "Surah Ar-Rum • 30:21",
  },
  timeline: [
    {
      time: "5:30 PM",
      title: "Welcome Reception",
      description: "Arrival of guests, artisanal Arabic coffee (Gahwa), Medjool dates & ambient oud melodies.",
      icon: "welcome",
    },
    {
      time: "6:30 PM",
      title: "The Nikah Ceremony",
      description: "Sacred marriage vows, Quranic recitation, and exchange of rings in the grand courtyard.",
      icon: "ceremony",
    },
    {
      time: "8:00 PM",
      title: "Royal Banquet Dinner",
      description: "A lavish multi-course feast celebrating Mediterranean & Levantine culinary traditions.",
      icon: "dinner",
    },
    {
      time: "9:30 PM",
      title: "The Cake Cutting & Zaffe",
      description: "Joyous traditional music, live dabke performance, cake cutting, and dancing until late.",
      icon: "celebration",
    },
  ],
  venue: {
    name: "The Royal Palm Palace",
    tagline: "The Grand Emerald Ballroom & Courtyard",
    address: "Palace Avenue, Crescent Gardens",
    cityState: "Dubai, United Arab Emirates",
    googleMapsUrl: "https://maps.google.com/?q=The+Palace+Downtown+Dubai",
    note: "Complimentary valet parking available at the grand porte-cochère entrance.",
  },
  rsvp: {
    deadline: "November 15, 2026",
    maxGuests: 4,
    options: {
      accept: "Joyfully Accept",
      decline: "Regretfully Decline",
    },
    dietaryOptions: [
      "Standard Gourmet (Halal)",
      "Vegetarian",
      "Vegan",
      "Gluten-Free",
    ],
  },
  audio: {
    title: "Nocturne of the Rose Garden",
    artist: "Acoustic Oud & Classical Strings",
    src: "https://cdn.freesound.org/previews/530/530415_11861866-lq.mp3",
  },
};
