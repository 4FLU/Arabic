﻿import React from "react";
import { motion } from "framer-motion";
import { weddingConfig } from "../config/weddingConfig";
import { GirihPattern, ElegantDivider } from "../assets/patterns";

export const ArabicQuote: React.FC = () => {
  const { arabic, english, surahOrSource } = weddingConfig.arabicQuote;

  return (
    <section
      id="quote"
      className="relative py-28 sm:py-36 px-4 sm:px-8 w-full overflow-hidden bg-gradient-to-b from-transparent via-[#F9D2BA]/15 to-transparent"
    >
      <GirihPattern opacity={0.03} />

      {/* Ambient soft glow in center */}
      <div className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 h-[500px] w-[500px] rounded-full bg-[#F9D2BA]/30 blur-3xl -z-10" />

      <div className="max-w-4xl mx-auto text-center space-y-8 relative z-10">
        {/* Top subtle ornament */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="flex justify-center"
        >
          <div className="h-8 w-8 rounded-full border border-[#C5A059]/60 flex items-center justify-center bg-cream shadow-sm">
            <div className="h-3 w-3 rounded-full bg-[#1D4533]" />
          </div>
        </motion.div>

        {/* Large Majestic Arabic Calligraphy */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1.0, delay: 0.1 }}
          className="space-y-4"
        >
          <p
            dir="rtl"
            className="font-arabic text-3xl sm:text-5xl lg:text-6xl text-[#1D4533] leading-[1.8] tracking-wide font-normal px-4 drop-shadow-sm select-none"
          >
            {arabic}
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          <ElegantDivider className="my-2" />
        </motion.div>

        {/* English Translation */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.9, delay: 0.3 }}
          className="space-y-4 max-w-2xl mx-auto"
        >
          <blockquote className="font-serif italic text-lg sm:text-2xl text-[#5E3122] leading-relaxed font-normal">
            "{english}"
          </blockquote>

          <p className="font-serif text-xs sm:text-sm font-semibold tracking-[0.25em] text-[#C5A059] uppercase">
            {surahOrSource}
          </p>
        </motion.div>
      </div>
    </section>
  );
};
