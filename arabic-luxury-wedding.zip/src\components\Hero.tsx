﻿import React from "react";
import { motion } from "framer-motion";
import { Calendar, ChevronDown, Sparkles } from "lucide-react";
import { weddingConfig } from "../config/weddingConfig";
import { WeddingCake3D } from "./WeddingCake3D";
import { GirihPattern, ElegantDivider } from "../assets/patterns";

export const Hero: React.FC = () => {
  return (
    <section
      id="hero"
      className="relative min-h-screen w-full flex flex-col justify-between items-center pt-28 pb-12 px-4 sm:px-6 lg:px-8 overflow-hidden"
    >
      {/* Background Girih Lattice Pattern */}
      <GirihPattern opacity={0.035} />

      {/* Subtle radial gradients for depth */}
      <div className="pointer-events-none absolute -top-40 -left-40 h-96 w-96 rounded-full bg-[#F9D2BA]/25 blur-3xl" />
      <div className="pointer-events-none absolute top-1/3 -right-40 h-[500px] w-[500px] rounded-full bg-[#1D4533]/8 blur-3xl" />

      {/* Main Hero Content */}
      <div className="relative z-10 w-full max-w-6xl my-auto grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
        {/* Left Column: Text & Wedding Announcement */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.0, ease: [0.16, 1, 0.3, 1] }}
          className="lg:col-span-7 flex flex-col items-center lg:items-start text-center lg:text-left space-y-6"
        >
          {/* Welcome Pill Tag */}
          <div className="inline-flex items-center gap-2 rounded-full border border-[#C5A059]/40 bg-cream/70 px-4 py-1.5 backdrop-blur-md shadow-sm">
            <Sparkles className="h-3.5 w-3.5 text-[#C5A059]" />
            <span className="font-serif text-xs font-semibold tracking-widest text-[#1D4533] uppercase">
              {weddingConfig.event.title}
            </span>
          </div>

          {/* Subtitle */}
          <p className="font-serif italic text-base sm:text-lg text-[#5E3122]/85 tracking-wide max-w-xl">
            {weddingConfig.event.subtitle}
          </p>

          {/* Prominent Names with Arabic Luxury Typography */}
          <div className="w-full space-y-1 sm:space-y-2 py-1">
            <h1 className="font-serif text-4xl sm:text-6xl xl:text-7xl font-bold tracking-tight text-[#1D4533] leading-none">
              {weddingConfig.couple.bride.name}
            </h1>
            <div className="flex items-center justify-center lg:justify-start gap-4 my-2">
              <span className="h-[1px] w-12 bg-gradient-to-r from-transparent to-[#C5A059]" />
              <span className="font-serif italic text-2xl sm:text-3xl text-[#5E3122]">
                &
              </span>
              <span className="h-[1px] w-12 bg-gradient-to-l from-transparent to-[#C5A059]" />
            </div>
            <h1 className="font-serif text-4xl sm:text-6xl xl:text-7xl font-bold tracking-tight text-[#1D4533] leading-none">
              {weddingConfig.couple.groom.name}
            </h1>
          </div>

          {/* Date & Day Badge */}
          <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3 pt-2">
            <div className="flex items-center gap-2.5 rounded-2xl border border-[#C5A059]/40 bg-cream/80 px-5 py-2.5 shadow-sm backdrop-blur-md">
              <Calendar className="h-4 w-4 text-[#1D4533]" />
              <div className="text-left">
                <p className="text-xs uppercase font-medium tracking-wider text-brown/70">
                  {weddingConfig.event.dayOfWeek}
                </p>
                <p className="font-serif text-sm sm:text-base font-bold text-[#1D4533]">
                  {weddingConfig.event.dateFormatted} • {weddingConfig.event.time}
                </p>
              </div>
            </div>

            <a
              href="#rsvp"
              className="rounded-2xl bg-[#1D4533] px-6 py-3 text-xs sm:text-sm font-semibold tracking-wider text-cream border border-[#C5A059]/50 shadow-md transition-all duration-300 hover:bg-[#143527] hover:scale-[1.02] hover:shadow-lg uppercase"
            >
              RSVP Now
            </a>
          </div>

          {/* Elegant Ornamental Divider */}
          <div className="w-full max-w-sm pt-2">
            <ElegantDivider />
          </div>
        </motion.div>

        {/* Right Column: Interactive 3D Wedding Cake */}
        <motion.div
          initial={{ opacity: 0, scale: 0.92 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.2, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
          className="lg:col-span-5 flex flex-col items-center justify-center relative w-full"
        >
          {/* Glassmorphic backdrop podium card for the 3D model */}
          <div className="relative w-full flex flex-col items-center rounded-3xl border border-[#C5A059]/30 bg-gradient-to-b from-cream/60 via-cream/40 to-cream/20 p-4 sm:p-6 shadow-[0_16px_40px_0_rgba(29,69,51,0.08)] backdrop-blur-md">
            {/* Corner Arabic ornamental accents */}
            <div className="absolute top-3 left-3 h-4 w-4 border-t-2 border-l-2 border-[#C5A059]/60 rounded-tl-md" />
            <div className="absolute top-3 right-3 h-4 w-4 border-t-2 border-r-2 border-[#C5A059]/60 rounded-tr-md" />
            <div className="absolute bottom-3 left-3 h-4 w-4 border-b-2 border-l-2 border-[#C5A059]/60 rounded-bl-md" />
            <div className="absolute bottom-3 right-3 h-4 w-4 border-b-2 border-r-2 border-[#C5A059]/60 rounded-br-md" />

            {/* 3D Cake Canvas */}
            <WeddingCake3D />

            <div className="mt-2 text-center">
              <p className="font-serif text-xs italic tracking-widest text-[#5E3122]/80 uppercase">
                A Symbolic Confection of Sweet Beginnings
              </p>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Scroll to Discover Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2, duration: 0.8 }}
        className="relative z-10 flex flex-col items-center gap-1.5 pt-8 text-[#5E3122]/75 hover:text-[#1D4533] transition-colors"
      >
        <a
          href="#wedding"
          className="flex flex-col items-center gap-1.5 focus:outline-none"
        >
          <span className="font-serif text-[11px] font-semibold tracking-[0.25em] uppercase">
            Scroll to Discover
          </span>
          <motion.div
            animate={{ y: [0, 6, 0] }}
            transition={{ repeat: Infinity, duration: 1.8, ease: "easeInOut" }}
          >
            <ChevronDown className="h-4 w-4 text-[#C5A059]" />
          </motion.div>
        </a>
      </motion.div>
    </section>
  );
};
