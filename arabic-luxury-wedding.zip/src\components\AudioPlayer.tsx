﻿import React, { useEffect, useRef, useState } from "react";
import { VolumeX } from "lucide-react";
import { weddingConfig } from "../config/weddingConfig";

interface AudioPlayerProps {
  isMuted: boolean;
  toggleAudio: () => void;
}

export const AudioPlayer: React.FC<AudioPlayerProps> = ({
  isMuted,
  toggleAudio,
}) => {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const synthIntervalRef = useRef<number | null>(null);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    if (!isMuted) {
      const playPromise = audio.play();
      if (playPromise !== undefined) {
        playPromise
          .then(() => setIsPlaying(true))
          .catch(() => {
            // If browser blocks autoplay or network audio fails, start subtle gentle ambient synth chime
            startAmbientSynth();
          });
      }
    } else {
      audio.pause();
      setIsPlaying(false);
      stopAmbientSynth();
    }

    return () => {
      stopAmbientSynth();
    };
  }, [isMuted]);

  // Gentle Web Audio API fallback in the key of D major (warm romantic pentatonic scale)
  const startAmbientSynth = () => {
    if (synthIntervalRef.current) return;
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();

      const notes = [293.66, 369.99, 440.0, 554.37, 587.33]; // D4, F#4, A4, C#5, D5
      setIsPlaying(true);

      const playChime = () => {
        if (ctx.state === "suspended") {
          ctx.resume();
        }
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        const freq = notes[Math.floor(Math.random() * notes.length)];
        osc.type = "sine";
        osc.frequency.setValueAtTime(freq, ctx.currentTime);

        gain.gain.setValueAtTime(0.001, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.04, ctx.currentTime + 0.3);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 3.0);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start();
        osc.stop(ctx.currentTime + 3.2);
      };

      playChime();
      synthIntervalRef.current = window.setInterval(playChime, 3200);
    } catch {
      // AudioContext unavailable
    }
  };

  const stopAmbientSynth = () => {
    if (synthIntervalRef.current) {
      clearInterval(synthIntervalRef.current);
      synthIntervalRef.current = null;
    }
  };

  return (
    <div className="fixed bottom-5 right-5 z-40">
      <audio
        ref={audioRef}
        src={weddingConfig.audio.src}
        loop
        preload="auto"
        className="hidden"
      />

      <button
        onClick={toggleAudio}
        className={`group flex items-center gap-2.5 rounded-full border border-[#C5A059]/40 py-2 px-3.5 shadow-lg backdrop-blur-md transition-all duration-300 ${
          !isMuted && isPlaying
            ? "bg-[#1D4533] text-cream border-[#C5A059]"
            : "bg-cream/80 text-[#5E3122] hover:bg-cream"
        }`}
        title={isMuted ? "Play Ambient Music" : "Mute Music"}
        aria-label="Toggle background music"
      >
        {!isMuted && isPlaying ? (
          <>
            <div className="flex items-end gap-0.5 h-3.5 w-3">
              <span className="h-full w-0.5 rounded-full bg-[#F9D2BA] animate-[pulse_1s_ease-in-out_infinite]" />
              <span className="h-2/3 w-0.5 rounded-full bg-[#F9D2BA] animate-[pulse_1.4s_ease-in-out_infinite]" />
              <span className="h-4/5 w-0.5 rounded-full bg-[#F9D2BA] animate-[pulse_0.8s_ease-in-out_infinite]" />
            </div>
            <span className="hidden sm:inline-block text-[11px] font-serif font-bold uppercase tracking-widest text-[#F9D2BA]">
              Music Playing
            </span>
          </>
        ) : (
          <>
            <VolumeX className="h-4 w-4 text-[#5E3122]/70" />
            <span className="hidden sm:inline-block text-[11px] font-serif font-semibold uppercase tracking-widest text-brown/70">
              Music Muted
            </span>
          </>
        )}
      </button>
    </div>
  );
};
