﻿import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import {
  Clock,
  Calendar,
  Sparkles,
  Download,
  ExternalLink,
  GlassWater,
  HeartHandshake,
  Utensils,
  Music,
} from "lucide-react";
import { weddingConfig } from "../config/weddingConfig";
import { GirihPattern, ElegantDivider } from "../assets/patterns";

export const WeddingDetails: React.FC = () => {
  // Live countdown timer state
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  });

  useEffect(() => {
    const targetDate = new Date(weddingConfig.event.dateISO).getTime();

    const updateTimer = () => {
      const now = new Date().getTime();
      const difference = targetDate - now;

      if (difference > 0) {
        setTimeLeft({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
          minutes: Math.floor((difference / 1000 / 60) % 60),
          seconds: Math.floor((difference / 1000) % 60),
        });
      }
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);
    return () => clearInterval(interval);
  }, []);

  // Calendar .ics download generator
  const downloadICS = () => {
    const icsContent = [
      "BEGIN:VCALENDAR",
      "VERSION:2.0",
      "PRODID:-//Amira and Zayd Wedding//EN",
      "BEGIN:VEVENT",
      "SUMMARY:Wedding of Amira & Zayd",
      `DESCRIPTION:Join us to celebrate the wedding ceremony & reception of Amira & Zayd at ${weddingConfig.venue.name}.`,
      `LOCATION:${weddingConfig.venue.name}, ${weddingConfig.venue.address}, ${weddingConfig.venue.cityState}`,
      "DTSTART:20261212T143000Z",
      "DTEND:20261212T210000Z",
      "STATUS:CONFIRMED",
      "END:VEVENT",
      "END:VCALENDAR",
    ].join("\r\n");

    const blob = new Blob([icsContent], { type: "text/calendar;charset=utf-8" });
    const link = document.createElement("a");
    link.href = window.URL.createObjectURL(blob);
    link.setAttribute("download", "amira-zayd-wedding.ics");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Google Calendar URL generator
  const googleCalendarUrl = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=Wedding+of+Amira+%26+Zayd&dates=20261212T143000Z/20261212T210000Z&details=Wedding+Ceremony+and+Royal+Reception+of+Amira+%26+Zayd+at+${encodeURIComponent(
    weddingConfig.venue.name
  )}&location=${encodeURIComponent(
    weddingConfig.venue.address + ", " + weddingConfig.venue.cityState
  )}`;

  const getTimelineIcon = (icon: string) => {
    switch (icon) {
      case "welcome":
        return <GlassWater className="h-5 w-5 text-[#C5A059]" />;
      case "ceremony":
        return <HeartHandshake className="h-5 w-5 text-[#1D4533]" />;
      case "dinner":
        return <Utensils className="h-5 w-5 text-[#5E3122]" />;
      case "celebration":
        return <Music className="h-5 w-5 text-[#C5A059]" />;
      default:
        return <Sparkles className="h-5 w-5 text-[#1D4533]" />;
    }
  };

  return (
    <section
      id="wedding"
      className="relative py-20 px-4 sm:px-6 lg:px-8 w-full max-w-6xl mx-auto overflow-hidden"
    >
      <GirihPattern opacity={0.025} />

      {/* Header with Arabic Architectural Flavor */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8 }}
        className="text-center space-y-3 mb-16"
      >
        <span className="font-serif text-xs font-bold tracking-[0.3em] uppercase text-[#1D4533]">
          Order of the Sacred Union
        </span>
        <h2 className="font-serif text-3xl sm:text-5xl font-bold tracking-tight text-[#1D4533]">
          The Wedding
        </h2>
        <p className="font-serif italic text-base text-[#5E3122]/80 max-w-lg mx-auto">
          We invite you to share in these cherished moments as our lives intertwine in holy matrimony.
        </p>
        <ElegantDivider />
      </motion.div>

      {/* Main Glass Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 lg:gap-8 items-stretch">
        {/* Left Card: Core Date & Times Glass Hero Panel */}
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="md:col-span-6 lg:col-span-5 flex flex-col justify-between rounded-3xl border border-[#C5A059]/40 bg-gradient-to-br from-cream/90 via-cream/70 to-[#F9D2BA]/30 p-8 shadow-[0_8px_32px_0_rgba(29,69,51,0.1)] backdrop-blur-xl relative overflow-hidden"
        >
          {/* Subtle background crest */}
          <div className="absolute -right-10 -bottom-10 h-44 w-44 rounded-full bg-[#1D4533]/5 blur-2xl pointer-events-none" />

          <div className="space-y-6">
            <div className="inline-flex items-center gap-2 rounded-full border border-[#C5A059]/50 bg-cream/90 px-3.5 py-1 text-xs font-serif font-bold uppercase tracking-wider text-[#1D4533]">
              <Calendar className="h-3.5 w-3.5 text-[#C5A059]" />
              Official Date
            </div>

            <div>
              <p className="font-serif text-lg tracking-widest text-[#5E3122] uppercase font-semibold">
                {weddingConfig.event.dayOfWeek}
              </p>
              <h3 className="font-serif text-3xl sm:text-4xl font-bold text-[#1D4533] my-1">
                {weddingConfig.event.dateFormatted}
              </h3>
              <p className="font-serif italic text-lg text-[#5E3122]/90">
                Beginning at {weddingConfig.event.time}
              </p>
            </div>

            {/* Ceremony & Reception Specific Times */}
            <div className="grid grid-cols-2 gap-4 pt-4 border-t border-[#C5A059]/30">
              <div className="rounded-2xl border border-[#C5A059]/30 bg-cream/75 p-4 text-center">
                <span className="text-[11px] font-bold uppercase tracking-wider text-brown/70 block">
                  Nikah Ceremony
                </span>
                <span className="font-serif text-lg font-bold text-[#1D4533] mt-1 block">
                  {weddingConfig.event.ceremonyTime}
                </span>
              </div>
              <div className="rounded-2xl border border-[#C5A059]/30 bg-cream/75 p-4 text-center">
                <span className="text-[11px] font-bold uppercase tracking-wider text-brown/70 block">
                  Reception Banquet
                </span>
                <span className="font-serif text-lg font-bold text-[#1D4533] mt-1 block">
                  {weddingConfig.event.receptionTime}
                </span>
              </div>
            </div>

            {/* Dress code advisory */}
            <div className="rounded-2xl bg-[#1D4533]/5 p-4 border border-[#1D4533]/15 text-xs text-[#5E3122] space-y-1">
              <span className="font-bold tracking-wider uppercase text-[#1D4533] block">
                Dress Code
              </span>
              <p>{weddingConfig.event.dressCode}</p>
            </div>
          </div>

          {/* Add to Calendar Actions */}
          <div className="pt-6 space-y-2">
            <span className="text-[11px] font-semibold tracking-wider text-brown/70 uppercase block text-center">
              Add to your calendar
            </span>
            <div className="flex gap-2">
              <a
                href={googleCalendarUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 flex items-center justify-center gap-1.5 rounded-xl border border-[#C5A059]/50 bg-cream/90 py-2.5 px-3 text-xs font-semibold text-[#1D4533] transition-all hover:bg-cream hover:shadow-sm"
              >
                <ExternalLink className="h-3.5 w-3.5 text-[#C5A059]" />
                Google Calendar
              </a>
              <button
                onClick={downloadICS}
                className="flex-1 flex items-center justify-center gap-1.5 rounded-xl bg-[#1D4533] py-2.5 px-3 text-xs font-semibold text-cream transition-all hover:bg-[#143527] shadow-sm"
              >
                <Download className="h-3.5 w-3.5 text-[#F9D2BA]" />
                Apple / Outlook
              </button>
            </div>
          </div>
        </motion.div>

        {/* Right Card: Countdown Timer & Program Timeline */}
        <motion.div
          initial={{ opacity: 0, x: 30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="md:col-span-6 lg:col-span-7 flex flex-col justify-between space-y-6"
        >
          {/* Glass Countdown Timer Panel */}
          <div className="rounded-3xl border border-[#C5A059]/40 bg-gradient-to-r from-cream/80 via-cream/60 to-cream/80 p-6 sm:p-7 shadow-[0_8px_32px_0_rgba(29,69,51,0.08)] backdrop-blur-xl">
            <div className="flex items-center justify-between mb-4">
              <span className="font-serif text-xs font-bold uppercase tracking-widest text-[#1D4533]">
                Countdown to the Celebration
              </span>
              <Clock className="h-4 w-4 text-[#C5A059]" />
            </div>

            <div className="grid grid-cols-4 gap-2 sm:gap-4 text-center">
              {[
                { label: "Days", value: timeLeft.days },
                { label: "Hours", value: timeLeft.hours },
                { label: "Minutes", value: timeLeft.minutes },
                { label: "Seconds", value: timeLeft.seconds },
              ].map((item) => (
                <div
                  key={item.label}
                  className="rounded-2xl border border-[#C5A059]/30 bg-cream/90 py-3 sm:py-4 px-2 shadow-sm"
                >
                  <span className="font-serif text-2xl sm:text-4xl font-bold text-[#1D4533] block">
                    {String(item.value).padStart(2, "0")}
                  </span>
                  <span className="text-[10px] sm:text-xs font-semibold uppercase tracking-wider text-brown/70 mt-1 block">
                    {item.label}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Timeline Schedule Cards */}
          <div className="rounded-3xl border border-[#C5A059]/40 bg-cream/70 p-6 sm:p-7 shadow-[0_8px_32px_0_rgba(29,69,51,0.08)] backdrop-blur-xl space-y-5">
            <span className="font-serif text-xs font-bold uppercase tracking-widest text-[#1D4533] block mb-2">
              Timeline of Events
            </span>

            <div className="relative space-y-4 before:absolute before:left-5 before:top-2 before:bottom-2 before:w-0.5 before:bg-[#C5A059]/30">
              {weddingConfig.timeline.map((item, idx) => (
                <div key={idx} className="relative flex items-start gap-4 group">
                  {/* Icon Node */}
                  <div className="relative z-10 flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-[#C5A059]/60 bg-cream shadow-sm transition-transform duration-300 group-hover:scale-110">
                    {getTimelineIcon(item.icon)}
                  </div>
                  {/* Text Details */}
                  <div className="flex-1 rounded-2xl border border-[#C5A059]/20 bg-cream/60 p-3.5 backdrop-blur-sm transition-all duration-300 group-hover:bg-cream/90 group-hover:shadow-sm">
                    <div className="flex items-center justify-between mb-1">
                      <h4 className="font-serif font-bold text-sm sm:text-base text-[#1D4533]">
                        {item.title}
                      </h4>
                      <span className="rounded-full bg-[#1D4533]/10 px-2.5 py-0.5 text-[11px] font-semibold text-[#1D4533]">
                        {item.time}
                      </span>
                    </div>
                    <p className="text-xs text-[#5E3122]/80 leading-relaxed">
                      {item.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};
